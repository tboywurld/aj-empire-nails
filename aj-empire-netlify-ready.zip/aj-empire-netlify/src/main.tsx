import React from "react";
import ReactDOM from "react-dom/client";
import { Toaster } from "sonner";
import HomePage from "./routes/index";
import "./styles.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <HomePage />
    <Toaster richColors position="top-center" />
  </React.StrictMode>
);
