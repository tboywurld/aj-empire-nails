import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Sparkles, Truck, Crown, ShoppingBag, Heart, Star, ArrowRight,
  MessageCircle, Send, MapPin, Mail, Instagram, Music2, Menu, X,
  Zap, Gem, Package, Headphones, ChevronRight, Check,
} from "lucide-react";
import heroNails from "@/assets/hero-nails.jpg";
import handModel from "@/assets/hand-model.jpg";
import productsFlatlay from "@/assets/products-flatlay.jpg";
import productPressOn from "@/assets/product-press-on.jpg";
import productGel from "@/assets/product-gel.jpg";
import productAcrylic from "@/assets/product-acrylic.jpg";
import productCharms from "@/assets/product-charms.jpg";
import logoAJ from "@/assets/logo-aj-empire.png";


const WHATSAPP = "https://wa.me/2349112136737";
const TELEGRAM = "https://t.me/AJEMPIRETHENAILBOSS";
const TIKTOK = "https://www.tiktok.com/@aj.empire";

const waLink = (msg: string) =>
  `${WHATSAPP}?text=${encodeURIComponent(msg)}`;

export default function HomePage() {
  return (
    <div className="relative overflow-x-hidden bg-background text-foreground">
      <Nav />
      <Hero />
      <Marquee />
      <Trust />
      <Collections />
      <Wholesale />
      <WhyUs />
      <Social />
      <Testimonials />
      <Delivery />
      <FinalCTA />
      <Footer />
      <FloatingWhatsApp />
      <MobileStickyCTA />
    </div>
  );
}

/* ---------------- NAV ---------------- */
function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const links = [
    ["Shop", "#collections"],
    ["Wholesale", "#wholesale"],
    ["Why Us", "#why"],
    ["Reviews", "#reviews"],
    ["Contact", "#contact"],
  ];
  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "glass shadow-soft py-3" : "py-5 bg-transparent"
      }`}
    >
      <div className="mx-auto max-w-7xl px-5 md:px-8 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2.5">
          <img
            src={logoAJ}
            alt="AJ EMPIRE — The Nail Boss butterfly A monogram logo"
            width={48}
            height={48}
            className="w-10 h-10 md:w-12 md:h-12 object-contain drop-shadow-[0_4px_12px_rgba(232,150,150,0.35)]"
          />
          <span className="font-display text-lg md:text-xl font-bold tracking-tight">
            AJ EMPIRE <span className="hidden sm:inline text-muted-foreground font-normal">| The Nail Boss</span>
          </span>
        </a>
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          {links.map(([l, h]) => (
            <a key={l} href={h} className="relative hover:text-accent transition-colors after:content-[''] after:absolute after:-bottom-1 after:left-0 after:w-0 after:h-px after:bg-accent hover:after:w-full after:transition-all">
              {l}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <a href={WHATSAPP} target="_blank" rel="noreferrer"
            className="hidden md:inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-primary text-primary-foreground text-sm font-semibold hover:bg-gradient-luxe hover:scale-105 transition-all">
            Shop Now <ArrowRight className="w-4 h-4" />
          </a>
          <button className="md:hidden p-2" onClick={() => setOpen(!open)} aria-label="Menu">
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="md:hidden glass mt-3 mx-5 rounded-2xl p-5 animate-fade-up">
          <div className="flex flex-col gap-4">
            {links.map(([l, h]) => (
              <a key={l} href={h} onClick={() => setOpen(false)} className="text-base font-medium">{l}</a>
            ))}
            <a href={WHATSAPP} target="_blank" rel="noreferrer"
              className="mt-2 inline-flex justify-center items-center gap-2 px-5 py-3 rounded-full bg-gradient-luxe text-primary-foreground font-semibold">
              Shop Now <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

/* ---------------- HERO ---------------- */
function Hero() {
  return (
    <section id="top" className="relative min-h-screen pt-32 pb-20 overflow-hidden bg-gradient-blush">
      {/* glow orbs */}
      <div className="absolute -top-40 -left-40 w-[480px] h-[480px] rounded-full bg-hot-pink/20 blur-3xl animate-float-y" />
      <div className="absolute -bottom-40 -right-32 w-[520px] h-[520px] rounded-full bg-rose-gold/30 blur-3xl animate-float-x" />

      <div className="relative mx-auto max-w-7xl px-5 md:px-8 grid lg:grid-cols-2 gap-12 items-center">
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-xs font-semibold tracking-widest uppercase text-foreground/80">
            <Sparkles className="w-3.5 h-3.5 text-hot-pink" /> Abraka • Delta State • Nigeria
          </span>
          <h1 className="mt-6 font-display font-black leading-[0.95] text-[clamp(2.6rem,7vw,5.5rem)]">
            Nigeria's <br />
            <span className="shimmer-text italic">Luxury Nail Plug</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-xl leading-relaxed">
            Wholesale & retail nail products at unbeatable prices. Trendy collections, premium quality, and{" "}
            <span className="text-foreground font-semibold">fast nationwide delivery</span>.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#collections" className="group inline-flex items-center gap-2 px-7 py-4 rounded-full bg-gradient-luxe text-primary-foreground font-semibold shadow-luxe hover:scale-105 transition-transform">
              Shop Now <ShoppingBag className="w-4 h-4 group-hover:rotate-12 transition" />
            </a>
            <a href="#wholesale" className="inline-flex items-center gap-2 px-7 py-4 rounded-full bg-primary text-primary-foreground font-semibold hover:bg-foreground/90 transition">
              Join Wholesale <Crown className="w-4 h-4" />
            </a>
            <a href={WHATSAPP} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-7 py-4 rounded-full glass font-semibold hover:bg-white transition">
              <MessageCircle className="w-4 h-4 text-hot-pink" /> WhatsApp
            </a>
          </div>

          <div className="mt-10 flex flex-wrap gap-2.5">
            {[
              { i: Truck, t: "Fast Delivery" },
              { i: Gem, t: "Affordable Luxury" },
              { i: Heart, t: "Trusted by Nail Techs" },
              { i: Package, t: "Wholesale Available" },
            ].map(({ i: Icon, t }) => (
              <span key={t} className="inline-flex items-center gap-2 px-3.5 py-2 rounded-full bg-white/70 border border-white text-xs font-semibold text-foreground/80 shadow-soft">
                <Icon className="w-3.5 h-3.5 text-accent" /> {t}
              </span>
            ))}
          </div>
        </div>

        {/* Hero visual */}
        <div className="relative">
          <div className="relative aspect-[4/5] max-w-[560px] mx-auto">
            <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-luxe blur-2xl opacity-40" />
            <img
              src={heroNails}
              alt="Luxury press-on nails flat lay"
              width={1536} height={1536}
              className="relative w-full h-full object-cover rounded-[2.5rem] shadow-luxe"
            />
            {/* floating cards */}
            <div className="absolute -left-4 md:-left-10 top-1/4 glass rounded-2xl p-4 shadow-soft animate-float-y w-44">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full bg-gradient-luxe grid place-items-center">
                  <Star className="w-4 h-4 text-primary-foreground" fill="currentColor" />
                </div>
                <div>
                  <p className="text-xs font-bold">4.9 / 5</p>
                  <p className="text-[10px] text-muted-foreground">1000+ orders</p>
                </div>
              </div>
            </div>
            <div className="absolute -right-3 md:-right-8 bottom-10 glass rounded-2xl p-4 shadow-soft animate-float-x w-48">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full bg-hot-pink/20 grid place-items-center">
                  <Truck className="w-4 h-4 text-hot-pink" />
                </div>
                <div>
                  <p className="text-xs font-bold">Delivered today</p>
                  <p className="text-[10px] text-muted-foreground">Lagos → Abuja → PH</p>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 px-5 py-2.5 rounded-full bg-primary text-primary-foreground text-xs font-semibold tracking-widest uppercase shadow-luxe animate-pulse-glow">
              Where Nail Bosses Shop
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- MARQUEE ---------------- */
function Marquee() {
  const items = [
    "Luxury Nails",
    "Unbeatable Prices",
    "Fast Delivery Nationwide",
    "Wholesale & Retail",
    "Trusted Nail Plug",
    "Press-On • Gel • Acrylic • Charms",
  ];
  return (
    <div className="bg-primary text-primary-foreground py-5 overflow-hidden border-y border-foreground/20">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...items, ...items, ...items].map((t, i) => (
          <span key={i} className="mx-8 font-display italic text-xl md:text-2xl flex items-center gap-8">
            {t} <Sparkles className="w-4 h-4 text-accent" />
          </span>
        ))}
      </div>
    </div>
  );
}

/* ---------------- TRUST ---------------- */
function Trust() {
  const stats = [
    { n: "1,000+", l: "Orders Delivered" },
    { n: "500+", l: "Wholesale Clients" },
    { n: "36", l: "States Served" },
    { n: "24h", l: "Fast Dispatch" },
  ];
  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-xs tracking-[0.3em] uppercase text-accent font-bold">Trusted Nail Vendor</p>
          <h2 className="mt-3 text-4xl md:text-5xl font-display font-bold">The Empire Speaks for Itself</h2>
        </div>
        <div className="mt-14 grid grid-cols-2 lg:grid-cols-4 gap-5">
          {stats.map((s) => (
            <div key={s.l} className="relative group rounded-3xl p-8 bg-gradient-blush border border-border hover-lift overflow-hidden">
              <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-gradient-luxe opacity-20 group-hover:scale-150 transition-transform" />
              <p className="relative font-display text-5xl md:text-6xl font-black text-gradient-luxe">{s.n}</p>
              <p className="relative mt-2 text-sm font-medium text-muted-foreground">{s.l}</p>
            </div>
          ))}
        </div>

        {/* TikTok-style review cards */}
        <div className="mt-14 grid md:grid-cols-3 gap-5">
          {[
            { name: "@beautybyzainab", text: "Shipped same day to Kano. Quality crazy 🔥", color: "from-hot-pink/15 to-rose-gold/10" },
            { name: "@nailsby_tomi", text: "My go-to wholesale plug. Prices unbeatable!", color: "from-rose-gold/20 to-blush/30" },
            { name: "@aj.empire.fan", text: "Look at the chrome finish ✨ obsessed!!!", color: "from-blush/40 to-hot-pink/10" },
          ].map((r) => (
            <div key={r.name} className={`rounded-3xl p-6 bg-gradient-to-br ${r.color} border border-white shadow-soft hover-lift`}>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-gradient-luxe grid place-items-center text-primary-foreground font-bold">
                  {r.name[1].toUpperCase()}
                </div>
                <div>
                  <p className="text-sm font-bold">{r.name}</p>
                  <div className="flex gap-0.5 text-hot-pink">
                    {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="w-3 h-3" fill="currentColor" />)}
                  </div>
                </div>
              </div>
              <p className="mt-4 text-base font-medium leading-relaxed">{r.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- COLLECTIONS ---------------- */
function Collections() {
  const products = [
    { name: "Press-On Nails", img: productPressOn, tag: "Bestseller" },
    { name: "Gel Polish Set", img: productGel, tag: "Trending" },
    { name: "Acrylic Powders", img: productAcrylic, tag: "Pro Pick" },
    { name: "Nail Charms", img: productCharms, tag: "New In" },
    { name: "Wholesale Bundle", img: productsFlatlay, tag: "Bulk Deal", wide: true },
    { name: "Chrome Tips", img: handModel, tag: "Viral" },
  ];
  return (
    <section id="collections" className="py-20 md:py-32 bg-gradient-blush relative">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <p className="text-xs tracking-[0.3em] uppercase text-accent font-bold">Featured Collections</p>
            <h2 className="mt-3 text-4xl md:text-6xl font-display font-bold leading-tight">
              Shop The <span className="italic shimmer-text">Empire</span>
            </h2>
            <p className="mt-3 text-muted-foreground max-w-md">Curated nail essentials for every boss — from press-ons to wholesale bundles.</p>
          </div>
          <a href={WHATSAPP} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold hover:text-accent transition">
            View all on WhatsApp <ChevronRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {products.map((p) => (
            <article
              key={p.name}
              className={`group relative rounded-3xl overflow-hidden bg-card border border-border hover-lift ${
                p.wide ? "col-span-2 md:col-span-2" : ""
              }`}
            >
              <div className={`relative overflow-hidden ${p.wide ? "aspect-[2/1.1]" : "aspect-square"}`}>
                <img
                  src={p.img}
                  alt={p.name}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition" />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-primary text-primary-foreground text-[10px] font-bold tracking-wider uppercase">
                  {p.tag}
                </span>
                <a
                  href={waLink(`Hi AJ EMPIRE! I'd like to order: ${p.name} 💅🏽`)}
                  target="_blank" rel="noreferrer"
                  aria-label={`Quick add ${p.name}`}
                  className="absolute top-3 right-3 w-10 h-10 rounded-full glass grid place-items-center opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all hover:bg-gradient-luxe hover:text-primary-foreground"
                >
                  <ShoppingBag className="w-4 h-4" />
                </a>
                <a
                  href={waLink(`Hi AJ EMPIRE! Quick order for: ${p.name}. Please send details ✨`)}
                  target="_blank" rel="noreferrer"
                  className="absolute bottom-3 left-3 right-3 py-2.5 rounded-full bg-white text-foreground text-xs font-bold text-center opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all"
                >
                  Quick Order
                </a>
              </div>
              <div className="p-4 md:p-5">
                <h3 className="font-display text-base md:text-lg font-semibold">{p.name}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Premium quality • Tap to order</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- WHOLESALE ---------------- */
function Wholesale() {
  const perks = [
    "Bulk discounts up to 40% off",
    "Reliable stock availability",
    "Priority dispatch",
    "Dedicated wholesale support",
    "Restock alerts on top sellers",
    "Free delivery on big orders",
  ];
  return (
    <section id="wholesale" className="py-20 md:py-32 bg-gradient-onyx text-primary-foreground relative overflow-hidden">
      <div className="absolute top-20 left-10 w-72 h-72 rounded-full bg-rose-gold/30 blur-3xl" />
      <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-hot-pink/20 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 md:px-8 grid lg:grid-cols-2 gap-14 items-center">
        <div>
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark text-xs font-semibold tracking-widest uppercase">
            <Crown className="w-3.5 h-3.5 text-accent" /> Wholesale Empire
          </span>
          <h2 className="mt-6 font-display font-black text-4xl md:text-6xl leading-[1.05]">
            Start Your Nail Business With <span className="italic text-gradient-luxe">AJ EMPIRE</span>
          </h2>
          <p className="mt-5 text-base md:text-lg text-primary-foreground/70 max-w-lg">
            Join hundreds of nail technicians and resellers stocking up with Nigeria's most trusted nail plug.
          </p>
          <ul className="mt-8 grid sm:grid-cols-2 gap-3">
            {perks.map((p) => (
              <li key={p} className="flex items-start gap-3 text-sm">
                <span className="mt-0.5 w-5 h-5 rounded-full bg-gradient-luxe grid place-items-center shrink-0">
                  <Check className="w-3 h-3 text-primary" strokeWidth={3} />
                </span>
                {p}
              </li>
            ))}
          </ul>
          <div className="mt-10 flex flex-wrap gap-3">
            <a href={WHATSAPP} target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 px-7 py-4 rounded-full bg-gradient-luxe text-primary font-bold shadow-luxe hover:scale-105 transition">
              Become a Wholesale Partner <ArrowRight className="w-4 h-4" />
            </a>
            <a href={TELEGRAM} target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 px-7 py-4 rounded-full glass-dark font-semibold hover:bg-white/10 transition">
              <Send className="w-4 h-4" /> Telegram Channel
            </a>
          </div>
        </div>
        <div className="relative">
          <div className="relative aspect-square max-w-lg mx-auto rounded-[2.5rem] overflow-hidden shadow-luxe">
            <img src={productsFlatlay} alt="Wholesale nail bundle" loading="lazy" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/60 via-transparent to-transparent" />
          </div>
          <div className="absolute -top-6 -right-4 md:right-0 glass-dark rounded-2xl p-5 shadow-luxe animate-float-y">
            <p className="text-xs uppercase tracking-widest text-accent font-bold">Save up to</p>
            <p className="font-display text-5xl font-black text-gradient-luxe">40%</p>
            <p className="text-xs text-primary-foreground/70">on bulk orders</p>
          </div>
          <div className="absolute -bottom-4 left-0 md:-left-6 glass-dark rounded-2xl p-4 shadow-luxe animate-float-x flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-luxe grid place-items-center">
              <Package className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-bold">Min order ₦25k</p>
              <p className="text-[10px] text-primary-foreground/70">Mix & match products</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- WHY US ---------------- */
function WhyUs() {
  const items = [
    { i: Zap, t: "Unbeatable Prices", d: "Direct supplier prices passed straight to you — no middleman markup." },
    { i: Truck, t: "Fast Delivery", d: "Same-day dispatch from Delta State. Anywhere in Nigeria, fast." },
    { i: Gem, t: "Premium Products", d: "Tested quality on every press-on, polish, charm and tool we ship." },
    { i: Sparkles, t: "Trendy Collections", d: "Constantly restocked with the looks blowing up on TikTok & IG." },
    { i: Headphones, t: "Trusted Service", d: "Real humans on WhatsApp — order help, advice & restock alerts." },
    { i: Crown, t: "Wholesale Ready", d: "Built for nail technicians and beauty resellers across Nigeria." },
  ];
  return (
    <section id="why" className="py-20 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-xs tracking-[0.3em] uppercase text-accent font-bold">Why The Nail Boss</p>
          <h2 className="mt-3 text-4xl md:text-6xl font-display font-bold">
            Built for <span className="italic shimmer-text">Nail Bosses</span>
          </h2>
        </div>
        <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {items.map(({ i: Icon, t, d }) => (
            <div key={t} className="group relative rounded-3xl p-7 bg-card border border-border hover-lift overflow-hidden">
              <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-gradient-luxe opacity-10 group-hover:opacity-30 group-hover:scale-125 transition-all duration-700" />
              <div className="relative w-14 h-14 rounded-2xl bg-gradient-luxe grid place-items-center shadow-glow group-hover:rotate-6 transition-transform">
                <Icon className="w-7 h-7 text-primary-foreground" />
              </div>
              <h3 className="relative mt-5 font-display text-2xl font-bold">{t}</h3>
              <p className="relative mt-2 text-sm text-muted-foreground leading-relaxed">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- SOCIAL ---------------- */
function Social() {
  return (
    <section className="py-20 md:py-32 bg-gradient-blush relative overflow-hidden">
      <div className="absolute top-10 right-10 w-72 h-72 rounded-full bg-hot-pink/20 blur-3xl" />
      <div className="mx-auto max-w-7xl px-5 md:px-8 grid lg:grid-cols-[1fr_1.2fr] gap-12 items-center relative">
        <div>
          <p className="text-xs tracking-[0.3em] uppercase text-accent font-bold">As Seen On TikTok</p>
          <h2 className="mt-3 font-display font-black text-5xl md:text-7xl leading-[0.95]">
            Follow <br /> The <span className="italic shimmer-text">Nail Boss</span>
          </h2>
          <p className="mt-5 text-muted-foreground max-w-md">
            Viral product showcases, customer unboxings, and nail transformations — daily.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={TIKTOK} target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-primary text-primary-foreground font-semibold hover:scale-105 transition">
              <Music2 className="w-4 h-4" /> @aj.empire
            </a>
            <a href={TELEGRAM} target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full glass font-semibold hover:bg-white transition">
              <Send className="w-4 h-4 text-hot-pink" /> Telegram
            </a>
          </div>
          <div className="mt-10 grid grid-cols-3 gap-4 max-w-sm">
            {[{ n: "12K", l: "Followers" }, { n: "500+", l: "Videos" }, { n: "2.5M", l: "Likes" }].map((s) => (
              <div key={s.l} className="text-center">
                <p className="font-display text-3xl font-black text-gradient-luxe">{s.n}</p>
                <p className="text-xs text-muted-foreground mt-1">{s.l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Mock TikTok feed */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[
            { img: handModel, likes: "72k", comments: "3.2k" },
            { img: productPressOn, likes: "48k", comments: "1.8k" },
            { img: heroNails, likes: "91k", comments: "4.6k" },
            { img: productCharms, likes: "33k", comments: "2.1k" },
            { img: productGel, likes: "57k", comments: "2.9k" },
            { img: productsFlatlay, likes: "84k", comments: "3.7k" },
          ].map((item, i) => (
            <div key={i} className={`relative rounded-2xl overflow-hidden shadow-soft hover-lift group ${i % 2 === 0 ? "aspect-[3/4]" : "aspect-[3/4] mt-6"}`}>
              <img src={item.img} alt="" loading="lazy" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-transparent to-transparent" />
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-primary-foreground text-[11px] font-semibold">
                <span className="flex items-center gap-1"><Heart className="w-3 h-3" fill="currentColor" /> {item.likes}</span>
                <span className="flex items-center gap-1"><MessageCircle className="w-3 h-3" /> {item.comments}</span>
              </div>
              <div className="absolute top-2 right-2 w-8 h-8 rounded-full glass-dark grid place-items-center opacity-0 group-hover:opacity-100 transition">
                <Music2 className="w-3.5 h-3.5 text-primary-foreground" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- TESTIMONIALS ---------------- */
function Testimonials() {
  const reviews = [
    { name: "Tomiwa A.", city: "Lagos", text: "Fast delivery! Got my order in 2 days. The press-ons are top-tier 💅🏽", rating: 5 },
    { name: "Aisha B.", city: "Kano", text: "Affordable and original! My clients keep coming back asking where I shop.", rating: 5 },
    { name: "Chioma E.", city: "Port Harcourt", text: "My clients love these nails! Wholesale prices saved my business 🙌", rating: 5 },
    { name: "Hadiza M.", city: "Abuja", text: "Best nail plug in Nigeria. Period. The packaging is so luxe!", rating: 5 },
  ];
  return (
    <section id="reviews" className="py-20 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-xs tracking-[0.3em] uppercase text-accent font-bold">Real Boss Reviews</p>
          <h2 className="mt-3 text-4xl md:text-6xl font-display font-bold">Loved Across <span className="italic shimmer-text">Nigeria</span></h2>
        </div>
        <div className="mt-14 grid md:grid-cols-2 gap-5">
          {reviews.map((r) => (
            <div key={r.name} className="rounded-3xl p-7 bg-gradient-blush border border-white shadow-soft hover-lift">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-luxe grid place-items-center text-primary-foreground font-bold text-lg">
                    {r.name[0]}
                  </div>
                  <div>
                    <p className="font-bold">{r.name}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="w-3 h-3" /> {r.city}</p>
                  </div>
                </div>
                <div className="flex text-hot-pink">
                  {Array.from({ length: r.rating }).map((_, i) => <Star key={i} className="w-4 h-4" fill="currentColor" />)}
                </div>
              </div>
              <div className="mt-5 relative rounded-2xl bg-white p-5 shadow-soft">
                <div className="absolute -top-2 left-6 w-4 h-4 bg-white rotate-45" />
                <p className="text-base leading-relaxed">{r.text}</p>
                <p className="mt-3 text-[10px] text-muted-foreground">via WhatsApp ✓✓</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- DELIVERY ---------------- */
function Delivery() {
  const cities = ["Lagos", "Abuja", "Port Harcourt", "Kano", "Ibadan", "Benin", "Asaba", "Warri", "Enugu", "Kaduna", "Calabar", "Uyo"];
  return (
    <section className="py-20 md:py-32 bg-gradient-onyx text-primary-foreground relative overflow-hidden">
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-80 h-80 rounded-full bg-rose-gold blur-3xl animate-float-y" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-hot-pink blur-3xl animate-float-x" />
      </div>
      <div className="relative mx-auto max-w-7xl px-5 md:px-8 text-center">
        <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-dark text-xs font-semibold tracking-widest uppercase">
          <Truck className="w-3.5 h-3.5 text-accent" /> Nationwide Logistics
        </span>
        <h2 className="mt-6 font-display font-black text-4xl md:text-7xl leading-[1.02] max-w-4xl mx-auto">
          Fast Delivery <br /> Across <span className="italic text-gradient-luxe">Nigeria</span>
        </h2>
        <p className="mt-5 text-primary-foreground/70 max-w-xl mx-auto">
          Same-day dispatch from Abraka. Trusted logistics partners deliver to every state — fast, safe, tracked.
        </p>

        <div className="mt-12 relative max-w-3xl mx-auto">
          <div className="relative rounded-3xl glass-dark p-8 md:p-10 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-rose-gold/10 to-transparent" />
            <div className="relative grid grid-cols-3 md:grid-cols-4 gap-3">
              {cities.map((c, i) => (
                <div key={c} className="flex items-center gap-2 text-sm font-medium animate-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
                  <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                  {c}
                </div>
              ))}
            </div>
            <p className="relative mt-8 text-xs text-primary-foreground/60 tracking-widest uppercase">+ All 36 States</p>
          </div>

          <div className="absolute -top-4 -left-4 glass-dark rounded-2xl p-4 animate-float-y">
            <p className="text-xs uppercase tracking-widest text-accent font-bold">Dispatch</p>
            <p className="font-display text-2xl font-black">Within 24h</p>
          </div>
          <div className="absolute -bottom-4 -right-4 glass-dark rounded-2xl p-4 animate-float-x">
            <p className="text-xs uppercase tracking-widest text-accent font-bold">Avg Arrival</p>
            <p className="font-display text-2xl font-black">2–5 Days</p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FINAL CTA ---------------- */
function FinalCTA() {
  return (
    <section className="py-20 md:py-32 bg-gradient-blush">
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <div className="relative rounded-[2.5rem] overflow-hidden p-10 md:p-20 text-center bg-primary text-primary-foreground shadow-luxe">
          <div className="absolute -top-20 -left-20 w-80 h-80 rounded-full bg-gradient-luxe opacity-40 blur-3xl animate-float-y" />
          <div className="absolute -bottom-20 -right-20 w-96 h-96 rounded-full bg-hot-pink/40 blur-3xl animate-float-x" />
          <div className="relative">
            <Crown className="w-10 h-10 mx-auto text-accent" />
            <h2 className="mt-5 font-display font-black text-4xl md:text-7xl leading-[0.95]">
              Ready To Shop Like A <br />
              <span className="italic shimmer-text">Nail Boss?</span>
            </h2>
            <p className="mt-5 text-primary-foreground/70 max-w-xl mx-auto">
              Join Nigeria's fastest growing nail empire. Order in seconds — we ship in hours.
            </p>
            <div className="mt-9 flex flex-wrap justify-center gap-3">
              <a href={WHATSAPP} target="_blank" rel="noreferrer"
                className="inline-flex items-center gap-2 px-7 py-4 rounded-full bg-gradient-luxe text-primary font-bold shadow-glow hover:scale-105 transition">
                <MessageCircle className="w-4 h-4" /> Order on WhatsApp
              </a>
              <a href={TELEGRAM} target="_blank" rel="noreferrer"
                className="inline-flex items-center gap-2 px-7 py-4 rounded-full glass-dark font-semibold hover:bg-white/10 transition">
                <Send className="w-4 h-4" /> Join Telegram
              </a>
              <a href="#collections"
                className="inline-flex items-center gap-2 px-7 py-4 rounded-full bg-white text-foreground font-bold hover:scale-105 transition">
                Shop Collections <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FOOTER ---------------- */
function Footer() {
  return (
    <footer id="contact" className="bg-primary text-primary-foreground pt-20 pb-32 md:pb-12">
      <div className="mx-auto max-w-7xl px-5 md:px-8 grid md:grid-cols-4 gap-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <img
              src={logoAJ}
              alt="AJ EMPIRE logo"
              width={56}
              height={56}
              loading="lazy"
              className="w-14 h-14 object-contain bg-white/5 rounded-full p-1"
            />
            <span className="font-display text-2xl font-bold">AJ EMPIRE</span>
          </div>
          <p className="mt-2 text-sm text-primary-foreground/60 italic">The Nail Boss • Your Trusted Nail Plug</p>
          <p className="mt-6 text-sm text-primary-foreground/70 max-w-md leading-relaxed">
            Wholesale & retail nail products at unbeatable prices. Luxury nails, fast nationwide delivery, and a brand built for nail bosses.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.currentTarget;
              const input = form.elements.namedItem("email") as HTMLInputElement;
              const email = input?.value?.trim();
              if (!email) return;
              toast.success("You're in the empire! 👑", {
                description: `We'll send drops & restocks to ${email}.`,
              });
              form.reset();
            }}
            className="mt-6 flex gap-2 max-w-sm"
          >
            <input
              type="email"
              name="email"
              required
              placeholder="Your email"
              className="flex-1 px-4 py-3 rounded-full bg-white/10 border border-white/20 text-sm placeholder:text-primary-foreground/40 focus:outline-none focus:border-accent"
            />
            <button
              type="submit"
              className="px-5 py-3 rounded-full bg-gradient-luxe text-primary font-bold text-sm hover:scale-105 transition"
            >
              Join
            </button>
          </form>
        </div>
        <div>
          <p className="font-display text-lg font-bold mb-4">Quick Links</p>
          <ul className="space-y-2.5 text-sm text-primary-foreground/70">
            {[["Shop", "#collections"], ["Wholesale", "#wholesale"], ["Why Us", "#why"], ["Reviews", "#reviews"]].map(([l, h]) => (
              <li key={l}><a href={h} className="hover:text-accent transition">{l}</a></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="font-display text-lg font-bold mb-4">Connect</p>
          <ul className="space-y-3 text-sm text-primary-foreground/70">
            <li className="flex items-center gap-2"><MapPin className="w-4 h-4 text-accent" /> Abraka, Delta State</li>
            <li>
              <a href={WHATSAPP} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-accent transition">
                <MessageCircle className="w-4 h-4 text-accent" /> +234 911 213 6737
              </a>
            </li>
            <li>
              <a href={TELEGRAM} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-accent transition">
                <Send className="w-4 h-4 text-accent" /> @AJEMPIRETHENAILBOSS
              </a>
            </li>
            <li>
              <a href={TIKTOK} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-accent transition">
                <Music2 className="w-4 h-4 text-accent" /> @aj.empire
              </a>
            </li>
            <li className="flex items-center gap-2"><Instagram className="w-4 h-4 text-accent" /> @aj.empire</li>
          </ul>
        </div>
      </div>
      <div className="mt-14 pt-6 border-t border-white/10 mx-auto max-w-7xl px-5 md:px-8 flex flex-col md:flex-row gap-3 justify-between text-xs text-primary-foreground/50">
        <p>© {new Date().getFullYear()} AJ EMPIRE | The Nail Boss. All rights reserved.</p>
        <p>Crafted with 💅🏽 in Abraka, Nigeria</p>
      </div>
    </footer>
  );
}

/* ---------------- FLOATING & MOBILE STICKY ---------------- */
function FloatingWhatsApp() {
  return (
    <a
      href={WHATSAPP} target="_blank" rel="noreferrer"
      className="fixed bottom-24 md:bottom-6 right-5 z-40 w-14 h-14 rounded-full bg-gradient-luxe grid place-items-center shadow-luxe animate-pulse-glow hover:scale-110 transition"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="w-6 h-6 text-primary-foreground" />
    </a>
  );
}

function MobileStickyCTA() {
  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 z-40 p-3 glass border-t border-white/40">
      <div className="flex gap-2">
        <a href={WHATSAPP} target="_blank" rel="noreferrer"
          className="flex-1 inline-flex justify-center items-center gap-2 py-3 rounded-full bg-gradient-luxe text-primary font-bold text-sm shadow-luxe">
          <MessageCircle className="w-4 h-4" /> Order Now
        </a>
        <a href="#collections"
          className="flex-1 inline-flex justify-center items-center gap-2 py-3 rounded-full bg-primary text-primary-foreground font-bold text-sm">
          Shop <ShoppingBag className="w-4 h-4" />
        </a>
      </div>
    </div>
  );
}
